#!/usr/bin/env python
# coding: utf-8

# In[2]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter


# In[26]:


def ParsePHRATE (line, logObj):
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        logObj.event = "Physical channel throughput"
        logObj.msgType = ''
        measureSystems=''
        
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            measureSystems = int(line[3 + NumberOfContextID])
            logObj.modeSystem = MeasureSysConverter(measureSystems)
            
        if logObj.modeSystem == 'UMTS FDD' or logObj.modeSystem == 'UMTS TD-SCDMA':
            if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                logObj.DPDCHRateUL = int(line[4+NumberOfContextID]) 
                
        elif logObj.modeSystem == 'LTE FDD' or logObj.modeSystem == 'LTE TDD':
            if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                cellType = int(line[4+NumberOfContextID]) 
                
                if cellType == 2:#PDSCH
                    if ((10 + NumberOfContextID) < length) and (line[10 + NumberOfContextID] != ''):
                        logObj.PDSCHBitRate = int(line[10 + NumberOfContextID])
                        if ((12 + NumberOfContextID) < length) and (line[12 + NumberOfContextID] != ''):
                            cellType2 = int(line[12 + NumberOfContextID])
                            
                            if cellType2 == 0:
                                logObj.cellType = 'PCell'
                            if cellType2 == 1:
                                logObj.cellType = 'SCell 0'
                            if cellType2 == 2:
                                logObj.cellType = 'SCell 1'
                                
                elif cellType == 3:#PUSCH
                    if ((5 + NumberOfContextID) < length) and (line[5 + NumberOfContextID] != ''):
                        logObj.PUSCHBitRate = int(line[5 + NumberOfContextID])
                        if ((6 + NumberOfContextID) < length) and (line[6 + NumberOfContextID] != ''):
                            cellType2 = float (line[6 + NumberOfContextID])
                            cellType2 = int(cellType2)
                            if cellType2 == 0:
                                logObj.cellType = 'PCell'
                            if cellType2 == 1:
                                logObj.cellType = 'SCell 0'
                            if cellType2 == 2:
                                logObj.cellType = 'SCell 1'
        return 1
    else:
        return 0
#     except:
#         return 0

