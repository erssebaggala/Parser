#!/usr/bin/env python
# coding: utf-8

# In[2]:


from LogDTClass import LogDT
import copy
from MeasureSysConverter import MeasureSysConverter


# In[26]:


def ParseSPECTRUMSCAN (line, listOfLogObj,PREVIOUS_LAT,PREVIOUS_LONG,PREVIOUS_MCC,PREVIOUS_MNC):
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        contextID = 'Unknown'
        measureSystem = 'Unknown'
        logDTObj = LogDT()
        logDTObj.lat = PREVIOUS_LAT
        logDTObj.longg = PREVIOUS_LONG
        logDTObj.mcc = PREVIOUS_MCC
        logDTObj.mnc = PREVIOUS_MNC
        if (3 < length) and (line[3] != ''):
            contextID = line[3]
            
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            if line[3+NumberOfContextID] == '1':
                logDTObj.modeSystem = 'Scanning Mode'
                
        if logDTObj.modeSystem == 'Scanning Mode':    
            numberOfHeaderParamters = 0
            if ((4 + NumberOfContextID) < length) and (line[4 + NumberOfContextID] != '') :
                numberOfHeaderParamters = int(line[4 + NumberOfContextID])
            numberOfFrequencies = 0
            if ((5 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[5 + NumberOfContextID + numberOfHeaderParamters] != '') :
                numberOfFrequencies = int(line[5 + NumberOfContextID + numberOfHeaderParamters])
            if ((6 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[6 + NumberOfContextID + numberOfHeaderParamters] != '') :
                parametersPerFreq = int(line[6 + NumberOfContextID + numberOfHeaderParamters])
            
        for freq in range(0,numberOfFrequencies):
            currentLog = LogDT()
            currentLog = copy.deepcopy(logDTObj)

            for parameter in range(1,parametersPerFreq):
                if ((NumberOfContextID + 6 + numberOfHeaderParamters + (freq * parametersPerFreq)+ parameter) < length) and (line[ (freq * parametersPerFreq) + NumberOfContextID + 7 + numberOfHeaderParamters + parameter] != '') :
                    value = line[NumberOfContextID + 7 + numberOfHeaderParamters + parameter +  (freq * parametersPerFreq)]
                    
                    if parameter == 1:  
                        currentLog.Frequency = float(value)
                    elif parameter == 2:
                        currentLog.RxLevFull = float(value)
            listOfLogObj.append(currentLog)
                        
        return 1
    else:
        return 0
#     except:
#         return 0

