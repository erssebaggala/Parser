#!/usr/bin/env python
# coding: utf-8

# In[ ]:
from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter

def ParseDCHI (line, logObj):
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        codingType = 0
        logObj.event = "Data Channel Information"
        logObj.msgType = ''
        logObj.time = line[1]  
                   
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
        if logObj.modeSystem == 'GSM':
            if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                codingType = int(line[4+NumberOfContextID]) #add
                if codingType == 1:
                    logObj.Coding = '9.6' #add
                elif codingType == 2:
                    logObj.Coding = '14.4' #add
            if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                logObj.CSTSLUL = line[6+NumberOfContextID]
            if ((7 + NumberOfContextID) < length) and (line[7+NumberOfContextID] != '') :
                logObj.CSTSLDL = line[7+NumberOfContextID]

        return 1
    
    else:
        return 0
#     except:
#         return 0

