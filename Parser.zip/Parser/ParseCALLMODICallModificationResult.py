#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseCALLMODICallModificationResult(type):
    switcher = { 
        1: "Success",
        2: "Rejected",
        3: "Failed",
        4: "Timeout",
    } 
    return switcher.get(type, "Unknown")

