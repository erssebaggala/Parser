#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseMEILteParseMeasurementEvent(type):
    switcher = { 
        1: "Event A1",
        2: "Event A2",
        3: "Event A3",
        4: "Event A4",
        5: "Event A5",
        6: "Event A6",
        21: "Event B1",
        22: "Event B2",
    } 
    return switcher.get(type, "Unknown")

