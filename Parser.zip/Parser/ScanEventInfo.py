#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class ScanEventInfo:
    def __init__(self,ScanContextID ='',StartTime ='',EndTime =''):
        self.ScanContextID = ScanContextID
        self.StartTime = StartTime
        self.EndTime  = EndTime

