#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class RadioResourceInfo:
    def __init__(self,ContextId ='',Direction ='',ConnectionAttempt ='',ConnectionSetup ='',ConnectionEstablished ='',ConnectionFailure ='',ConnectionEnd=''):
        self.ContextId = ContextId
        self.Direction = Direction
        self.ConnectionAttempt  = ConnectionAttempt
        self.ConnectionSetup = ConnectionSetup
        self.ConnectionEstablished = ConnectionEstablished
        self.ConnectionFailure = ConnectionFailure
        self.ConnectionEnd = ConnectionEnd

