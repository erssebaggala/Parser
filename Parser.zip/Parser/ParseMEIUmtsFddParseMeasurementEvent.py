#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseMEIUmtsFddParseMeasurementEvent(type):
    switcher = { 
        1: "Event 1A",
        2: "Event 1B",
        3: "Event 1C",
        4: "Event 1D",
        5: "Event 1E",
        6: "Event 1F",
        7: "Event 1G",
        8: "Event 1H",
        9: "Event 1I",
        10: "Event 1J",
        21: "Event 2A",
        22: "Event 2B",
        23: "Event 2C",
        24: "Event 2D",
        25: "Event 2E",
        26: "Event 2F",
        31: "Event 3A",
        32: "Event 3B",
        33: "Event 3C",
        34: "Event 3D",
        41: "Event 4A",
        42: "Event 4B",
        51: "Event 5A",
        61: "Event 6A",
        62: "Event 6B",
        63: "Event 6C",
        64: "Event 6D",
        65: "Event 6E",
        66: "Event 6F",
        67: "Event 6G",
        71: "Event 7A",
        72: "Event 7B",
        73: "Event 7C",
    } 
    return switcher.get(type, "Unknown")

