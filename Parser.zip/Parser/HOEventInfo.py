#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class HOEventInfo:
    def __init__(self,HOAttempt ='',HOSuccess ='',HOFailure ='',HOContextID='',ModeSystem='',HOType=''):
        self.HOAttempt = HOAttempt
        self.HOSuccess = HOSuccess
        self.HOFailure  = HOFailure
        self.HOContextID = HOContextID
        self.ModeSystem = ModeSystem
        self.HOType = HOType

