#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseCADDropStatus(type):
    switcher = { 
        1: "Normal disconnect",
        2: "Dropped call",
        3: "Dropped out of service",
        4: "Dropped during handover/handoff/hard handover",
        5: "Test System Failure",
        6: "Timeout",
        11: "Voice quality synchronization lost",
        12: "TCH assignment failure",
        13: "Early release",
        14: "User Busy",
        20: "PPP error",
    } 
    return switcher.get(type, "Unknown")

