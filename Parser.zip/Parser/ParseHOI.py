#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
from HOEventInfo import HOEventInfo
from datetime import datetime
from parseHOFStringType import parseHOFStringType


# In[8]:


def ParseHOI (line, logObj,dictionary):
    length = len(line)
    if 2 < length:
        dataOfHOI = ''
        handoverContextID = 0
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
            if NumberOfContextID != 0:
                if(3 < length) and (line[3] != '') :
                    handoverContextID = int(line[3])
                    

        logObj.event = "Handover Information"
        logObj.msgType = 'Handover Information'
        dataOfHOI = "Handover Context ID: " + str(handoverContextID)

        handoverType = "Unknown"
        if handoverContextID in dictionary:
            handoverType = dictionary[handoverContextID]
        dataOfHOI += ';Handover Type: '+str(handoverType.HOType)
        
        numberOfHeaderParams = 0
        if((3 + NumberOfContextID) < length) and (line[3 + NumberOfContextID] != ''):
            numberOfHeaderParams = int(line[3 + NumberOfContextID])
                                      
        if numberOfHeaderParams > 0:
            if((4 + NumberOfContextID) < length) and (line[4 + NumberOfContextID] != ''):
                duration = line[4 + NumberOfContextID]
                duration += 'ms;'
                
                                      
        logObj.eventInfo = dataOfHOI
                                                 
        return 1


# In[ ]:




