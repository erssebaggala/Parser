#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseMimoMeasureMimoPart(type):
    switcher = { 
        0: "Port 0",
        1: "Port 1",
        2: "Port 2",
        3: "Port 3",
        100: "TX0-RX0 channel",
        101: "TX0-RX1 channel",
        102: "TX0-RX2 channel",
        103: "TX0-RX3 channel",
        110: "TX1-RX0 channel",
        111: "TX1-RX1 channel",
        112: "TX1-RX2 channel",
        113: "TX1-RX3 channel",
        120: "TX2-RX0 channel",
        121: "TX2-RX1 channel",
        122: "TX2-RX2 channel",
        123: "TX2-RX3 channel",
        130: "TX3-RX0 channel",
        131: "TX3-RX1 channel",
        132: "TX3-RX2 channel",
        133: "TX3-RX3 channel",
        
    } 
    return switcher.get(type, "Unknown")

