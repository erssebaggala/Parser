#!/usr/bin/env python
# coding: utf-8

# In[ ]:
from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter

def ParseLUA (line, logObj):
    dataOfLUA = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = int(line[2])
        luaContextID = 0
        luaType = 0
        logObj.event = "Location Area Update Attempt"
        logObj.msgType = 'LUA Attempt'
        logObj.time = line[1]  
        if (3 < length) and (line[3] != ''):
            luaContextID = int(line[3])
        if luaContextID > 0:
            dataOfLUA = 'Location Update Context ID: ' + str(luaContextID)
                   
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            luaType = int(line[4+NumberOfContextID])
            if luaType == 1:
                luaType = 'Combined location and routing/tracking area update'
            elif luaType == 2:
                luaType = 'Normal location area update'
            elif luaType == 3:
                luaType = 'Periodic update'
            elif luaType == 4:
                luaType = 'IMSI/ITSI attach'
            elif luaType == 5:
                luaType = 'Roaming location updating (TETRA)'
            elif luaType == 6:
                luaType = 'Migrating location updating (TETRA)'
            elif luaType == 7:
                luaType = 'Call restoration roaming location updating (TETRA)'
            elif luaType == 8:
                luaType = 'Call restoration migrating location updating (TETRA)'
            elif luaType == 9:
                luaType = 'Demand location updating (TETRA)'
            elif luaType == 10:
                luaType = 'Disabled MS updating (TETRA)'
            else:
                luaType = 'Unknown'
            
        
        dataOfLUA += ";Location Update Type: " + luaType 

        logObj.eventInfo = dataOfLUA 
        return 1
    else:
        dataOfLUA = "No of context id not found"
        return 0
#     except:
#         return 0

