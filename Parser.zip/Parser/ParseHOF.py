#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
from HOEventInfo import HOEventInfo
from datetime import datetime


# In[3]:


def ParseHOF (line, logObj,dictionary):
    length = len(line)
    if 2 < length:
        dataOfHOF = ''
        handoverContextID = 0
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
            if NumberOfContextID != 0:
                if(3 < length) and (line[3] != '') :
                    handoverContextID = int(line[3])
                    

        logObj.event = "Handover Fail"
        logObj.msgType = 'Handover Failure'
        dataOfHOF = "Handover Context ID: " + str(handoverContextID)
        measureSystems=''
        handoverType = "Unknown"
        
        if handoverContextID in dictionary:
            HOFInfo = dictionary[handoverContextID]
        else:
            HOFInfo = HOEventInfo()
            dictionary[handoverContextID] = HOFInfo
            HOFInfo = dictionary[handoverContextID]
            
        HOFInfo.HOFailure = line[1]
        HOFInfo.ModeSystem = logObj.modeSystem
        
        dictionary[handoverContextID] = HOFInfo
        tdelta = datetime.strptime(HOFInfo.HOFailure.split('.', 1)[0], '%H:%M:%S') - datetime.strptime(HOFInfo.HOAttempt.split('.', 1)[0], '%H:%M:%S')        
        failTime = float(tdelta.seconds)*1000 #MilliSeconds 

            
        dataOfHOF += ';"Handover Failure Time: '+str(failTime) + ';Handover Type: '+HOFInfo.HOType
        cause = 'Unknown'
        if logObj.modeSystem == 'GSM':
            if((3 + NumberOfContextID) < length) and (line[3 + NumberOfContextID] != '') : 
                cause = int (line[3 + NumberOfContextID])
                cause = ParseCauseHOF(cause)
        dataOfHOF += ';' + cause
        logObj.eventInfo = dataOfHOF
                                                 
        return 1

