#!/usr/bin/env python
# coding: utf-8

# In[12]:


class CallContextID:
    def __init__(self,Direction ='',CallAttempt ='',CallSetup ='',CallEstablished ='',CallFailure ='',CallEnd =''):
        self.Direction = Direction
        self.CallAttempt = CallAttempt
        self.CallSetup  = CallSetup
        self.CallEstablished = CallEstablished
        self.CallFailure = CallFailure
        self.CallEnd = CallEnd

