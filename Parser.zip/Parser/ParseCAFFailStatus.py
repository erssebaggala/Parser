#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseCAFFailStatus(type):
    switcher = { 
        1: "Timeout before connection", 
        2: "Call was released before connection", 
        3: "Service not available",
        4: "Incoming call rejected", 
        5: "Test system failure", 
        6: "SDCCH blocking",  
        7: "TCH blocking", 
        8: "RRC connection failed",
        9: "Radio bearer setup failed", 
        10: "SDCCH release", 
        11: "SDCCH drop",
        12: "TCH assignment failure", 
        13: "Incoming call not received",
        14: "User busy", 
        20: "PPP error",
    } 
    return switcher.get(type, "Unknown")

