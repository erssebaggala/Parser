#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def ParseStart (line):
    try:
        startDate = ""
        time = line[1]
        date = line[-1]
        date = date[1:-1]
        startDate = time + ' ' + date
        return startDate
    except:
        return "Start date not found"

