from LogDTClass import LogDT

def ParseDTRACE (line, logObj):
    length = len(line)
    if 2 < length:
        applicationProtocol = "Unknown"
        NumberOfContextID = int(line[2])
        streamStateInt = -1
        logObj.event = "Trace Route"
        logObj.msgType = ' '
        logObj.time = line[1]
        if (3 < length) and (line[3] != ''):
            dataTranferContextID = line[3]

        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.applicationProtocol = line[3 + NumberOfContextID]
            applicationProtocol = ParseApplicationProtocol(int(logObj.applicationProtocol))
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            logObj.Host = line[4 + NumberOfContextID] #add
        if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
            logObj.TraceHopCount = line[5 + NumberOfContextID]#add
        if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
            logObj.PingRTT = line[4 + NumberOfContextID] #add
        return 1
    else:
        return 0
#     except:
#         return 0

