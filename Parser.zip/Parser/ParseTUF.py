#!/usr/bin/env python
# coding: utf-8

# In[ ]:

from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from ParseTUFEmmCause import parseTUFEmmCause

def ParseTUF (line, logObj):
    
    dataOfTUF = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        TUFContextID = 0
        emmCause = 0
        logObj.event = "Tracking Area Update Failed"
        logObj.msgType = 'Failure'
        logObj.time = line[1]  
        if (3  < length) and (line[3] != '') :
            TUFContextID = line[3]
            dataOfTUF = "TAU Context ID: " + TUFContextID + ';'
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
            dataOfTUF += ('Measure System: ' + logObj.modeSystem) + ';'
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            emmCause = parseTUFEmmCause(int(line[4 + NumberOfContextID]))
        dataOfTUF += ('EMM Cause: ' + emmCause) 
        logObj.eventInfo = dataOfTUF 
        return 1
    
    else:
        dataOfTUF = "No of context id not found"
        return 0
#     except:
#         return 0

