#!/usr/bin/env python
# coding: utf-8

# In[ ]:

from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
def ParseTUA (line, logObj):
    dataOfTAU = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        TAUContextID = 0
        TAUType = 0
        logObj.event = "Tracking Area Update Attempt"
        logObj.msgType = 'Setup'
        logObj.time = line[1]  
        if (3  < length) and (line[3] != '') :
            TAUContextID = line[3]
            dataOfTAU = "TAU Context ID: " + TAUContextID + ';'
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
            dataOfTAU += ('Measure System: ' + logObj.modeSystem) + ';'
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            TAUType = int(line[4 + NumberOfContextID])
            if TAUType == 1:
                TAUType = 'Tracking Area Update'
            elif TAUType == 2:
                TAUType = 'Combined tracking area and location area update'
            elif TAUType == 3:
                TAUType = 'Combined tracking area and location area update with IMSI attach'
            elif TAUType == 4:
                TAUType = 'Periodic Update'
            dataOfTAU += ('TAU Type: ' + TAUType)
        
        logObj.eventInfo = dataOfTAU 
        return 1
    
    else:
        dataOfTAU = "No of context id not found"
        return 0
#     except:
#         return 0

