#!/usr/bin/env python
# coding: utf-8

# In[1]:


def parseCHITransmissionType(type):
    switcher = { 
        1: "Single antenna (P0)",
        2: "Transmit diversity",
        3: "Open SM",
        4: "Closed SM",
        5: "MU-MIMO",
        6: "Closed SM rank 1",
        7: "Single antenna (P5)",
        8: "Dual-layer (P7, P8)",
        9: "8 layer (P7-P14)",
    } 
    return switcher.get(type, "Unknown")

