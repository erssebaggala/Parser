#!/usr/bin/env python
# coding: utf-8

# In[2]:

import copy
from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter


# In[26]:


def ParseEDCHI (line, listOfLogObj,PREVIOUS_LAT,PREVIOUS_LONG,PREVIOUS_MCC,PREVIOUS_MNC):
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        contextID = 'Unknown'
        measureSystem = 'Unknown'
        logDTObj = LogDT()
        logDTObj.lat = PREVIOUS_LAT
        logDTObj.longg = PREVIOUS_LONG
        logDTObj.mcc = PREVIOUS_MCC
        logDTObj.mnc = PREVIOUS_MNC
        logDTObj.event = 'E-DCH Information'
        if (3 < length) and (line[3] != ''):
            contextID = line[3]
            
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            measureSystem = line[3+NumberOfContextID]
            logDTObj.modeSystem = MeasureSysConverter(int(measureSystem))
            
        numberOfHeaderParamters = 0
        if ((4 + NumberOfContextID) < length) and (line[4 + NumberOfContextID] != '') :
            numberOfHeaderParamters = int(line[4 + NumberOfContextID])
        if ((5 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[5 + NumberOfContextID + numberOfHeaderParamters] != '') :
            numberOfCells = int(line[5 + NumberOfContextID + numberOfHeaderParamters])
        if ((6 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[6 + NumberOfContextID + numberOfHeaderParamters] != '') :
            parametersPerCells = int(line[6 + NumberOfContextID + numberOfHeaderParamters])
            
        for cell in range(0,numberOfCells):
            currentLog = LogDT()
            currentLog = copy.deepcopy(logDTObj)

            for parameter in range(0,parametersPerCells):
                if ((NumberOfContextID + 7 + numberOfHeaderParamters + parameter) < length) and (line[NumberOfContextID + 7 + numberOfHeaderParamters + parameter] != '') :
                    value = line[NumberOfContextID + 7 + numberOfHeaderParamters + parameter]

                    if parameter == 0:  
                        currentLog.HSUPAChannel = int(value)
                    elif parameter == 1:
                        currentLog.HSUPASC = int(value)
                    elif parameter == 2:
                        currentLog.HSUPARLC = float(value)
                    elif parameter == 3:
                        currentLog.HICHAckPercentage = float(value)
                    elif parameter == 4:
                        currentLog.HICHNackPercentage = float(value)
                    elif parameter == 5:
                        currentLog.HICHDTXPercentage = float(value)

            listOfLogObj.append(currentLog)
                        
        return 1
    else:
        return 0
#     except:
#         return 0

