
from LogDTClass import LogDT

def ParseJitter (line, logObj):
    dataOfJitter = ""
    length = len(line)
    if 2 < length:
        applicationProtocol = "Unknown"
        NumberOfContextID = int(line[2])

        logObj.event = "Jitter"
        logObj.msgType = ''
        logObj.time = line[1]
        applicationProtocol = ''
        if (3 < length) and (line[3] != ''):
            dataTranferContextID = line[3]

        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.applicationProtocol = line[3 + NumberOfContextID]
            applicationProtocol = ParseApplicationProtocol(int(logObj.applicationProtocol))
            
         #add in logObj   
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            logObj.ULJitter = line[4+NumberOfContextID] #add
        if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
            logObj.DLJitter = line[5+NumberOfContextID] #add
        
        dataOfJitter = "Data Transfer Context ID: "+dataTranferContextID+";Application Protocol: "+applicationProtocol

        logObj.eventInfo = dataOfJitter
        return 1
    else:
        dataOfJitter = "No of context id not found"
        return 0
#     except:
#         return 0

