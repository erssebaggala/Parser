#!/usr/bin/env python
# coding: utf-8

# In[1]:


def parseCHIEXTChannelType(type):
    switcher = { 
        "1": "BCCH",
        "2": "CCCH",
        "3": "CBCH",
        "4": "SDCCH",
        "5": "RACH",
        "10": "TCH HR/0 TCH half rate, first half.",
        "11": "TCH HR/1 TCH half rate, second half.",
        "12": "TCH FR TCH full rate.",
        "13": "TCH EFR TCH enhanced full rate.",
        "14": "TCH FR 14.4 data TCH full rate, 14.4 kbs data.",
        "15": "TCH FR 9.6 data",
        "16": "TCH FR 7.2 data",
        "17": "TCH FR 4.8 data",
        "18": "TCH FR 2.4 data",
        "19": "TCH HR/0 4.8 data",
        "20": "TCH HR/1 4.8 data",
        "21": "TCH HR/0 2.4 data",
        "22": "TCH HR/1 2.4 data",
        "23": "TCH FR FACCH",
        "24": "TCH HR/0 FACCH",
        "25": "TCH HR/1 FACCH",
        "26": "AFS AMR adaptive full rate speech.",
        "27": "AHS AMR adaptive half rate speech.",
        "28": "WFS AMR adaptive full rate for wideband speech.",
        "50": "PBCCH",
        "51": "PCCCH",
        "60": "PDTCH",
    } 
    return switcher.get(type, "Unknown")

