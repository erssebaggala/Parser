#!/usr/bin/env python
# coding: utf-8

# In[ ]:
from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter

def ParseLUS (line, logObj):
    dataOfLUS = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = int(line[2])
        LUSContextID = 0
        LUSType = 0
        logObj.event = "Location Area Update Success"
        logObj.msgType = 'LUA Success'
        logObj.time = line[1]  
        if (3 < length) and (line[3] != ''):
            LUSContextID = line[3]
        if int(LUSContextID) > 0:
            dataOfLUS = 'Location Update Context ID: ' + LUSContextID
                   
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            logObj.OldLAC = int(line[4+NumberOfContextID]) #add
            dataOfLUS += (';Old LAC: ' + str(logObj.OldLAC)) 
        if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
            logObj.LAC = int(line[5+NumberOfContextID]) #add
            dataOfLUS += (';LAC: ' + str(logObj.LAC)) 
        if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
            logObj.mcc = int(line[6+NumberOfContextID]) #add
            dataOfLUS += (';MCC: ' + str(logObj.mcc))
        if ((7 + NumberOfContextID) < length) and (line[7+NumberOfContextID] != '') :
            logObj.mnc = int(line[7+NumberOfContextID]) #add
            dataOfLUS += (';MNC: ' + str(logObj.mnc))
        logObj.eventInfo = dataOfLUS 
        return 1
    
    else:
        dataOfLUS = "No of context id not found"
        return 0
#     except:
#         return 0

