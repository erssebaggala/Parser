#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from ParseCellMeasuresParseBand import parseCellMeasuresParseBand


# In[58]:


def ParseCELLMEAS (line, listOfLogObj,PREVIOUS_LAT,PREVIOUS_LONG,PREVIOUS_MCC,PREVIOUS_MNC):
    dataOfCELLMEAS = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        contextID = 'Unknown'
        numberOfHeaderParamters = 0
        numberOfCells = 0
        numberOfParametersPerCell = 0
        measureSystem = 'Unknown'
        if (3 < length) and (line[3] != ''):
            contextID = line[3]
            
        
        
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            measureSystem = line[3+NumberOfContextID]
            measureSystem = MeasureSysConverter(int(measureSystem))
            if measureSystem == 'GSM':
                if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                    numberOfHeaderParamters = int(line[4+NumberOfContextID])
                if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
                    numberOfCell = int(line[5+NumberOfContextID])
                if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                    numberOfParametersPerCell = int(line[6+NumberOfContextID])
                   
                for cell in range(0,numberOfCells):
                    currentLog = LogDT()
                    dataOfCELLMEAS = "Context ID:"+contextID
                    currentLog.eventInfo = dataOfCELLMEAS
                    currentLog.modeSystem = measureSystem
                    currentLog.event = 'Cell Measures'
                    currentLog.lat = PREVIOUS_LAT
                    currentLog.longg = PREVIOUS_LONG
                    currentLog.mcc = PREVIOUS_MCC
                    currentLog.mnc = PREVIOUS_MNC
                    
                    for parameter in range(0,numberOfParametersPerCell):
                        item = NumberOfContextID + 7 +(cell*numberOfParametersPerCell)
                        if parameter == 0:
                            if ((item) < length) and (line[item] != '') :
                                cellType = int(line[item])
                                if cellType == 0:
                                    currentLog.cellType = 'Neighbor'
                                elif cellType == 1:
                                    currentLog.cellType = 'Serving'
                                else:
                                    currentLog.cellType = 'Unknown'
                        elif parameter == 1:#Band
                            if ((item+parameter) < length) and (line[item+parameter] != '') : 
                                currentLog.Band = parseCellMeasuresParseBand(int(line[item+parameter]))
                        elif parameter == 2:#ARFCNCurrent
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.ARFCNCurrent = int(line[item+parameter])
                        elif parameter == 3:#BSIC
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.BSIC = int(line[item+parameter])
                        elif parameter == 4:#RxLevFull
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.RxLevFull = float(line[item+parameter])
                        elif parameter == 5:#RxLevSub
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.RxLevSub = int(line[item+parameter])
                        elif parameter == 6:#C1
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.C1 = float(line[item+parameter])
                        elif parameter == 7:#C2
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.C2 = int(line[item+parameter])
                        elif parameter == 8:#C31
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.C31 = float(line[item+parameter])
                        elif parameter == 9:#C32
                            if ((item+parameter) < length) and (line[item+parameter] != '') : 
                                currentLog.C32 = float(line[item+parameter])
                        elif parameter == 10:#HSCPriority
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.HSCPriority = float(line[item+parameter])
                        elif parameter == 11:#HSCThroughput
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.HSCThroughput = float(line[item+parameter])
                        elif parameter == 12:#CellId
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.CellId = float(line[item+parameter])
                        elif parameter == 13:#LAC
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.LAC = float(line[item+parameter])
                        elif parameter == 14:#RAC
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.RAC = int(line[item+parameter])
                        elif parameter == 15:#SrxLev
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.SrxLev = float(line[item+parameter])
                
                    listOfLogObj.append(currentLog) 
                
                        
            elif measureSystem == 'UMTS FDD':
                
                if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                    numberOfHeaderParamters = int(line[4+NumberOfContextID])
                if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
                    numberOfChannels = int(line[5+NumberOfContextID])
                if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                    numberOfParametersPerChannel = int(line[6+NumberOfContextID])
                if ((7 + NumberOfContextID+(numberOfChannels*numberOfParametersPerChannel)) < length) and (line[(7 + NumberOfContextID+(numberOfChannels*numberOfParametersPerChannel))] != '') :
                    numberOfCells = int(line[(7 + NumberOfContextID+(numberOfChannels*numberOfParametersPerChannel))])
                if ((8 + NumberOfContextID+(numberOfChannels*numberOfParametersPerChannel)) < length) and (line[(8 + NumberOfContextID+(numberOfChannels*numberOfParametersPerChannel))] != '') :
                    numberOfParametersPerCell = int(line[(8 + NumberOfContextID+(numberOfChannels*numberOfParametersPerChannel))])
                    
                for cell in range(0,numberOfCells):
                    currentLog = LogDT()
                    dataOfCELLMEAS = "Context ID:"+contextID
                    currentLog.eventInfo = dataOfCELLMEAS
                    currentLog.modeSystem = measureSystem
                    currentLog.lat = PREVIOUS_LAT
                    currentLog.longg = PREVIOUS_LONG
                    currentLog.mcc = PREVIOUS_MCC
                    currentLog.mnc = PREVIOUS_MNC
                    
                    currentLog.event = 'Cell Measures'
                    for parameter in range(0,numberOfParametersPerCell):
                        item = NumberOfContextID + 9 +(numberOfChannels*numberOfParametersPerChannel)+(cell*numberOfParametersPerCell)
                        if parameter == 0:
                            if ((item) < length) and (line[item] != '') :
                                cellType = int(line[item])
                                if cellType == 0:
                                    currentLog.cellType = 'Active'
                                elif cellType == 1:
                                    currentLog.cellType = 'Monitored'
                                elif cellType == 2:
                                    currentLog.cellType = 'Detected'
                                elif cellType == 3:
                                    currentLog.cellType = 'Undetected'
                                else:
                                    currentLog.cellType = 'Unknown'
                        elif parameter == 1:#Band
                            if ((item+parameter) < length) and (line[item+parameter] != '') : 
                                currentLog.Band = parseCellMeasuresParseBand(int(line[item+parameter]))
                        elif parameter == 2:#ChannelNum
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.ChannelNum = int(line[item+parameter])
                        elif parameter == 3:#servingSC
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.servingSC = int(line[item+parameter])
                        elif parameter == 4:#ServingCPICHEcNo
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.ServingCPICHEcNo = float(line[item+parameter])
                        elif parameter == 5:#STTD
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.STTD = int(line[item+parameter])
                        elif parameter == 6:#ServingCPICHRSCP
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.ServingCPICHRSCP = float(line[item+parameter])
                        elif parameter == 7:#ASSC
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.ASSC = int(line[item+parameter])
                        elif parameter == 8:#Squal
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.Squal = float(line[item+parameter])
                        elif parameter == 9:#SrxLev
                            if ((item+parameter) < length) and (line[item+parameter] != '') : 
                                currentLog.SrxLev = float(line[item+parameter])
                        elif parameter == 10:#Hqual
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.Hqual = float(line[item+parameter])
                        elif parameter == 11:#HrxLev
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.HrxLev = float(line[item+parameter])
                        elif parameter == 12:#Rqual
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.Rqual = float(line[item+parameter])
                        elif parameter == 13:#RrxLev
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.RrxLev = float(line[item+parameter])
                        elif parameter == 14:#OFF
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.OFF = int(line[item+parameter])
                        elif parameter == 15:#Tm
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.Tm = float(line[item+parameter])
                        elif parameter == 16:#Pathloss
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.Pathloss = float(line[item+parameter])
                    listOfLogObj.append(currentLog)
                                                            
            elif measureSystem == 'LTE FDD' or measureSystem == 'LTE TDD':
                if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                    numberOfHeaderParamters = int(line[4+NumberOfContextID])
                if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
                    numberOfCells = int(line[5+NumberOfContextID])        
                if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                    numberOfParametersPerCell = int(line[6+NumberOfContextID])
                    
                for cell in range(0,numberOfCells):
                    currentLog = LogDT()
                    dataOfCELLMEAS = "Context ID:"+contextID
                    currentLog.eventInfo = dataOfCELLMEAS
                    currentLog.modeSystem = measureSystem
                    currentLog.event = 'Cell Measures'
                    currentLog.lat = PREVIOUS_LAT
                    currentLog.longg = PREVIOUS_LONG
                    currentLog.mcc = PREVIOUS_MCC
                    currentLog.mnc = PREVIOUS_MNC
                    for parameter in range(0,numberOfParametersPerCell):
                        item = NumberOfContextID + 7 + (cell*numberOfParametersPerCell)
                        if parameter == 0:
                            if ((item) < length) and (line[item] != '') :
                                cellType = int(line[item])
                                if cellType == 0:
                                    currentLog.cellType = 'Serving'
                                elif cellType == 1:
                                    currentLog.cellType = 'Listed'
                                elif cellType == 2:
                                    currentLog.cellType = 'Detected'
                                elif cellType == 10:
                                    currentLog.cellType = 'SCell 0'
                                elif cellType == 11:
                                    currentLog.cellType = '"SCell 1'
                                else:
                                    currentLog.cellType = 'Unknown'
                        elif parameter == 1:
                            if ((item+parameter) < length) and (line[item+parameter] != '') : 
                                currentLog.Band = parseCellMeasuresParseBand(int(line[item+parameter]))
                        elif parameter == 2:#Channel Num
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.ChannelNum = int(line[item+parameter])
                        elif parameter == 3:#PCI
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.PCI = int(line[item+parameter])
                        elif parameter == 4:#RSSI
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.RSSI = float(line[item+parameter])
                        elif parameter == 5:#RSRP
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.RSRP = float(line[item+parameter])
                        elif parameter == 6:#RSRQ
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.RSRQ = float(line[item+parameter])
                        elif parameter == 7:#Timing
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.Timing = float(line[item+parameter])
                        elif parameter == 8:#Pathloss
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.Pathloss = float(line[item+parameter])
                  
                    listOfLogObj.append(currentLog)     
                
        
        return 1
    else:
        dataOfCELLMEAS = "No of context id not found"
        currentLog.eventInfo = dataOfCELLMEAS
        listOfLogObj.append(currentLog)
        
        return 0
#     except:
#         return 0

