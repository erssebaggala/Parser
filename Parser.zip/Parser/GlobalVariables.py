#!/usr/bin/env python
# coding: utf-8

# In[4]:


def init():
#Global variables.......
    global version
    version = ""
    global startDate
    startDate = ""
    global stopDate 
    stopDate = ""
    global PREVIOUS_LAT
    REVIOUS_LAT = ""
    global PREVIOUS_LONG
    PREVIOUS_LONG = ""
    global PREVIOUS_MNC
    PREVIOUS_MNC = ""
    global PREVIOUS_MCC
    PREVIOUS_MCC = ""
    global LOGDT_LIST
    LOGDT_LIST = []
    global CALL_INFO_DICTIONARY
    CALL_INFO_DICTIONARY = {}

