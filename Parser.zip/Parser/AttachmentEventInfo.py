#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class AttachmentEventInfo:
    def __init__(self,ContextId ='',Direction ='',Attempt ='',Setup ='',Established ='',Failure ='',End=''):
        self.ContextId = ContextId
        self.Direction = Direction
        self.Attempt  = Attempt
        self.Setup = Setup
        self.Established = Established
        self.Failure = Failure
        self.End = End

