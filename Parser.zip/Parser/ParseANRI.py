#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from ParseCellMeasuresParseBand import parseCellMeasuresParseBand


# In[8]:


def ParseANRI (line, logObj):
    length = len(line)
    if 2 < length:
        callContextID = 0
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
            if NumberOfContextID != 0:
                if(3 < length) and (line[3] != '') :
                    callContextID = int(line[3])
                    
        if callContextID > 0:
            logObj.eventInfo += " Call Context ID: " + callContextID + "; "
        
        measureSystem = MeasureSysConverter(items[3 + callContextIDCount])
        logObj.modeSystem = measureSystem
        numberOfHeaderParams = 0
        if((3 + NumberOfContextID) < length) and (line[3 + NumberOfContextID] != ''):
            numberOfHeaderParams = int(line[3 + NumberOfContextID])
        if((4 + NumberOfContextID) < length) and (line[4 + NumberOfContextID] != ''):
            param = int (line[4 + NumberOfContextID])
            if param == 1:
                logObj.ANRType = "CGI measurement configuration" 
            elif param == 2:
                logObj.ANRType = "CGI measurement report" 
        currentLog.CellType = "ANR"
        numberOfParams = 0
        if((5 + NumberOfContextID) < length) and (line[5 + NumberOfContextID] != ''):
            numberOfParams = int(line[5 + NumberOfContextID])
            for p in range(0, numberOfParams):
                paramNumber = 6 + callContextIDCount + p
                if ((paramNumber) < length) and (line[paramNumber] != ''):
                    if p == 0:
                        logObj.Band = parseCellMeasuresParseBand(line[paramNumber])
                    elif p == 1:
                        logObj.ChannelNum = int(line[paramNumber])
                    elif p == 2:
                        logObj.PhysicalCellID = int(line[paramNumber])
                    elif p == 3:
                        logObj.CellId = int(line[paramNumber])
                    elif p == 4:
                        logObj.LAC = int(line[paramNumber])
                    elif p == 5:
                        logObj.mcc = int(line[paramNumber])
                    elif p == 6:
                        logObj.mnc = int(line[paramNumber])
                
                
        return 1


# In[ ]:




