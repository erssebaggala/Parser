#!/usr/bin/env python
# coding: utf-8

# In[1]:


def parseDAFDataFailStatus(type):
    switcher = { 
        1: "User abort", 
        2: "Socket error", 
        3: "Protocol error or timeout",
        4: "Test system failure",
    } 
    return switcher.get(type, "Unknown")


# In[ ]:




