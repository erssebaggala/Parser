#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from ParseCellMeasuresParseBand import parseCellMeasuresParseBand


# In[3]:


def ParseNMISS (line, listOfLogObj, PREVIOUS_LAT,PREVIOUS_LONG,PREVIOUS_MCC,PREVIOUS_MNC):
    dataOfNMISS = ""
    length = len(line)
    if 2 < length:
        logObj = LogDT()
        logObj.lat = PREVIOUS_LAT
        logObj.longg = PREVIOUS_LONG
        logObj.mcc = PREVIOUS_MCC
        logObj.mnc = PREVIOUS_MNC
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        headerParams = 0
        logObj.time = line[1]  
        if ((3 + NumberOfContextID) < length) and (line[3 + NumberOfContextID] != ''):
            headerParams = line[3 + NumberOfContextID]
        for h in range(0,headerParams):
            currentLog = LogDT()
            currentLog = copy.deepcopy(logObj)
            paramNumber = h + 4 + NumberOfContextID
            
            if ((paramNumber) < length) and (line[paramNumber] != '') :
                if h == 0:
                    currentLog.CellType = "Serving";
                    currentLog.modeSystem = MeasureSysConverter(line[paramNumber]) 
                elif h == 1:
                    currentLog.Band = parseCellMeasuresParseBand(items[paramNumber])
                elif h == 2:
                    currentLog.ChannelNum = int(line[paramNumber]); 
                elif h == 3:
                    if currentLog.modeSystem == 'GSM':
                        currentLog.BSIC = int(items[paramNumber])
                    elif currentLog.modeSystem == 'UMTS FDD':
                        currentLog.SC = int(items[paramNumber])

        listOfLogObj.append(currentLog)
            
            
        numberOfMissingNeighbours = 0
        if ((4 + NumberOfContextID + headerParams) < length) and (line[4 + NumberOfContextID + headerParams] != '') :
            numberOfMissingNeighbours = int(line[4 + NumberOfContextID + headerParams])
            
            for c in range (0, numberOfMissingNeighbours):
                numberOfParamsPerNeighbour = 0
                if ((5 + NumberOfContextID + headerParams) < length) and (line[5 + NumberOfContextID + headerParams] != '') :
                    numberOfParamsPerNeighbour = int(line[5 + NumberOfContextID + headerParams])
                currentLog = LogDT()
                currentLog = copy.deepcopy(logObj)
                
                for p in range(0,numberOfParamsPerNeighbour):
                    paramNumber = 6 + NumberOfContextID + headerParams + (c * numberOfParamsPerNeighbour) + p
                    
                    if ((paramNumber) < length) and (line[paramNumber] != '') :
                        if p == 0:
                            currentLog.CellType = "Missing Neighbo";
                            currentLog.modeSystem = MeasureSysConverter(line[paramNumber]) 
                        elif p == 1:
                            if currentLog.modeSystem == 'GSM' or currentLog.modeSystem == 'UMTS FDD':
                                currentLog.NeighbourARFCN = int(line[paramNumber])   
                        elif p == 2:
                            if currentLog.modeSystem == 'GSM':
                                currentLog.BSIC = int(items[paramNumber])
                            elif currentLog.modeSystem == 'UMTS FDD':
                                currentLog.SC = int(items[paramNumber])

                        elif p== 3:
                            if currentLog.modeSystem == 'GSM':
                                currentLog.NeighbourRxLev = float(items[paramNumber])
                            elif currentLog.modeSystem == 'UMTS FDD':
                                currentLog.NeighbourEcNo = float(items[paramNumber])                        
                        elif p== 4:
                            if currentLog.modeSystem == 'GSM':
                                currentLog.Band = parseCellMeasuresParseBand(items[paramNumber])
                            elif currentLog.modeSystem == 'UMTS FDD':
                                currentLog.NeighbourRSCP = float(items[paramNumber])
                        elif p== 5:
                            if currentLog.modeSystem == 'UMTS FDD':
                                currentLog.NeighbourDiff2Strongest = float(items[paramNumber])
                        elif p== 6:
                            if currentLog.modeSystem == 'UMTS FDD':
                                currentLog.Band = parseCellMeasuresParseBand(items[paramNumber])
                                
                listOfLogObj.append(currentLog)

        return 1
    else:
        dataOfNMISS = "No of context id not found"
        return 0


# In[ ]:




