#!/usr/bin/env python
# coding: utf-8

# In[ ]:

from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
def ParseRUA (line, logObj):
    dataOfRUA = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        RUAContextID = 0
        RUAType = 0
        logObj.event = "Routing Area Update Attempt"
        logObj.msgType = 'Setup'
        logObj.time = line[1]  
        if (3  < length) and (line[3] != '') :
            RUAContextID = line[3]
            dataOfRUA = "RUA Context ID: " + RUAContextID
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            RUAType = int(line[4+NumberOfContextID]) #add
            if RUAType == 1:
                RUAType = 'Routing Area Update'
            elif RUAType == 2:
                RUAType = 'Combined routing area and location area update'
            elif RUAType == 3:
                RUAType = 'Combined routing area and location area update with IMSI attach'
            elif RUAType == 4:
                RUAType = 'Periodic Update'
            else:
                RUAType = 'Unknown'
            dataOfRUA += (";RAU Type: " + RUAType)
        logObj.eventInfo = dataOfRUA 
        return 1
    
    else:
        dataOfRUA = "No of context id not found"
        return 0
#     except:
#         return 0

