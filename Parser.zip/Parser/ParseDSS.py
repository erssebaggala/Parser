from LogDTClass import LogDT
from ParseApplicationProtocol import parseApplicationProtocol
def ParseDSS (line, logObj):
    dataOfDSS = ""
    length = len(line)
    if 2 < length:
        applicationProtocol = "Unknown"
        NumberOfContextID = int(line[2])
        streamStateInt = -1
        logObj.event = "Data Stream Status"
        logObj.msgType = ''
        logObj.time = line[1]
        if (3 < length) and (line[3] != ''):
            dataTranferContextID = line[3]

        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.applicationProtocol = line[3 + NumberOfContextID]
            applicationProtocol = ParseApplicationProtocol(int(logObj.applicationProtocol))
        if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') : 
            streamStateInt = int(line[5+NumberOfContextID])
            if streamStateInt == 0:
                logObj.streamState = "Uninitialized" #add
            elif streamStateInt == 1:
                logObj.streamState = "Stopped" #add
            elif streamStateInt == 2:
                logObj.streamState = "Buffering" #add
            elif streamStateInt == 3:
                logObj.streamState = "Streaming" #add
        if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
            logObj.streamBandwidth = line[6+NumberOfContextID] #add
        if ((7 + NumberOfContextID) < length) and (line[7+NumberOfContextID] != '') :
            logObj.streamResolution = line[7+NumberOfContextID] #add
        if ((8 + NumberOfContextID) < length) and (line[8+NumberOfContextID] != '') :
            logObj.StreamDuration = line[8+NumberOfContextID] #add
        if ((9 + NumberOfContextID) < length) and (line[9+NumberOfContextID] != '') :
            logObj.streamPosition = line[9+NumberOfContextID] #add
        if ((10 + NumberOfContextID) < length) and (line[10+NumberOfContextID] != '') :
            logObj.streamContent = line[10+NumberOfContextID] #add
        if ((11 + NumberOfContextID) < length) and (line[11+NumberOfContextID] != '') :
            logObj.streamVideoCodec = line[11+NumberOfContextID] #add
        if ((12 + NumberOfContextID) < length) and (line[12+NumberOfContextID] != '') :
            logObj.streamAudioCodec = line[12+NumberOfContextID] #add
        if ((13 + NumberOfContextID) < length) and (line[13+NumberOfContextID] != '') :
            logObj.fileSize = line[13+NumberOfContextID]
        return 1
    else:
        dataOfDSS = "No of context id not found"
        return 0
#     except:
#         return 0

