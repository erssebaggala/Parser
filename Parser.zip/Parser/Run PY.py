#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class CallContextId:
    def __init__(self,Direction ='',CallAttempt ='',CallSetup ='',CallEstablished ='',CallFailure ='',CallEnd =''):
        self.Direction = Direction
        self.CallAttempt = CallAttempt
        self.CallSetup  = CallSetup
        self.CallEstablished = CallEstablished
        self.CallFailure = CallFailure
        self.CallEnd = CallEnd


# In[7]:


import GlobalVariables
import Parser


# In[ ]:





# In[6]:


def func():
    return GlobalVariables.version


# In[ ]:




