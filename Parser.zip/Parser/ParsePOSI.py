from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter

def ParsePOSI (line, logObj):
    length = len(line)
    if 2 < length:
        NumberOfContextID = int(line[2])
        logObj.event = "Position report information"
        logObj.msgType = ' '
        logObj.time = line[1]
        measureSystems=''
        measurementEvent = 0
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            measureSystems = int(line[3 + NumberOfContextID])
            logObj.modeSystem = MeasureSysConverter(measureSystems)
        if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
            logObj.POSILongitude = float(line[6+NumberOfContextID]) #add
        if ((7 + NumberOfContextID) < length) and (line[7+NumberOfContextID] != '') :
            logObj.POSILatitude = float(line[7+NumberOfContextID]) #add
        if ((9 + NumberOfContextID) < length) and (line[9+NumberOfContextID] != '') :
            logObj.POSIConfidence = float(line[9+NumberOfContextID]) #add
                                            
        return 1
    else:
        return 0
#     except:
#         return 0

