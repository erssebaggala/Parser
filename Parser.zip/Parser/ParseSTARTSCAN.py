#!/usr/bin/env python
# coding: utf-8

# In[ ]:
from LogDTClass import LogDT
from ScanEventInfo import ScanEventInfo

def ParseSTARTSCAN (line,logObj,dictionary):
    length = len(line)
    if 2 < length:
        dataOfStartScan = ''
        scanContextID = 0
        NumberOfContextID = int(line[2])
        logObj.event = "Scanning Start"
        logObj.msgType = 'Setup'
        logObj.time = line[1]
        dataOfStartScan += 'Scanning Start'
        if (NumberOfContextID > 0) and (((3) < length) and (line[3] != '')):
            scanContextID = int(line[3])
        if scanContextID > 0:
            if scanContextID in dictionary:
                scanInfo = dictionary[scanContextID]
            else:
                scanInfo = ScanEventInfo()
                dictionary[scanContextID] = scanInfo
                scanInfo = dictionary[scanContextID]
            
            scanInfo.StartTime = logObj.time
            dataOfStartScan += (';Scanning Context ID:' + str(scanContextID))
            logObj.eventInfo = dataOfStartScan
        return 1
    else:
        return 0
#     except:
#         return 0

