#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseHOAHandoverType(type):
    switcher = { 
        "101": "GSM longernal handover",
        "102": "GSM handover between cells",
        "103": "GSM handover between systems",
        "104": "GSM handover between bands",
        "105": "GSM longernal handover between bands",
        "201": "DAMPS handoff between sectors or handoff to small diameter cell (SBI = 00)",
        "202": "DAMPS handoff to small diameter cell or handoff to large diameter cell (SBI = 01 or SBI = 10)",
        "203": "DAMPS handoff between systems",
        "301": "CDMA hard handoff",
        "303": "CDMA handoff between systems",
        "401": "UMTS FDD hard handover",
        "403": "UMTS FDD handover between systems",
        "501": "TD-SCDMA hard longer-frequency handover",
        "502": "TD-SCDMA hard longra-frequency handover",
        "503": "TD-SCDMA handover between systems",
        "504": "TD-SCDMA baton longer-frequency handover",
        "505": "TD-SCDMA baton longra-frequency handover",
        "600": "TETRA announced cell reselection type 1",
        "601": "TETRA announced cell reselection type 2",
        "602": "TETRA announced cell reselection type 3",
        "703": "GAN WLAN handover between systems",
        "801": "WiMAX handover between cells",
        "901": "LTE handover between cells",
        "902": "LTE handover between frequencies",
        "903": "LTE handover between bands",
        "904": "LTE handover between systems",
        "1001": "iDEN longra-cell",
        "1002": "iDEN longer-cell",
    } 
    return switcher.get(type, "Unknown")

