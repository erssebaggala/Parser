#!/usr/bin/env python
# coding: utf-8

# In[1]:


def parseLUFmmCause(type):
    switcher = { 
        "1": "Unallocated TMSI",
        "2": "IMSI unknown HLR",
        "3": "Illegal MS",
        "4": "IMSI unknown in VLR",
        "5": "IMEI not accepted",
        "6": "Illegal ME",
        "7": "GPRS services not allowed Combined LAU and RAU only.",
        "8": "GPRS services and nonGPRS services not allowed Combined LAU and RAU only.",
        "9": "MS identity cannot be derived by the network Combined LAU and RAU only.",
        "10": "Implicitly detached Combined LAU and RAU only.",
        "11": "PLMN not allowed",
        "12": "Location Area not allowed",
        "13": "National roaming not allowed in this location area",
        "14": "GPRS services not allowed in this PLMN Combined LAU and RAU only.",
        "15": "No suitable cells in location area",
        "16": "MSC temporarily not reachable Combined LAU and RAU only.",
        "20": "MAC failure",
        "21": "Synch failure",
        "22": "Congestion",
        "23": "GSM authentication unacceptable",
        "32": "Service option not supported",
        "33": "Requested service option not subscribed",
        "34": "Service option temporarily out of order",
        "38": "Call cannot be identified",
        "40": "No PDP context activated Combined LAU and RAU only.",
        "95": "Semantically incorrect message",
        "96": "Invalid mandatory information",
        "97": "Message type nonexistent or not implemented",
        "98": "Message type not compatible with the protocol state",
        "99": "Information element nonexistent or not implemented",
        "100": "Conditional IE error",
        "101": "Message not compatible with the protocol state",
        "111": "Protocol error, unspecified",
    } 
    return switcher.get(type, "Unknown")

