#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from HOEventInfo import HOEventInfo
from ParseCellMeasuresParseBand import parseCellMeasuresParseBand

# In[2]:


def ParseCELLINFO (line, listOfLogObj, PREVIOUS_LAT,PREVIOUS_LONG,PREVIOUS_MCC,PREVIOUS_MNC):
    dataOfCELLINFO = ""
    length = len(line)
    if 2 < length:
        logObj = LogDT()
        logObj.lat = PREVIOUS_LAT
        logObj.longg = PREVIOUS_LONG
        logObj.mcc = PREVIOUS_MCC
        logObj.mnc = PREVIOUS_MNC
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        numberOfHeaderParamters = 0   
        CELLINFOContextID = 0
        logObj.event = "Parse Cell Information"
        logObj.msgType = ''
        logObj.time = line[1]  
        if (3 < length) and (line[3] != ''):
            CELLINFOContextID = line[3]
        if CELLINFOContextID > 0:
            logObj.eventInfo = "Call Context ID: " + CELLINFOContextID + ";"
        if ((3 + CELLINFOContextID) < length) and (line[3+CELLINFOContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + CELLINFOContextID]))
        if logObj.modeSystem == 'UMTS TD-SCDMA':
            if ((4 + NumberOfContextID) < length) and (line[4 + NumberOfContextID] != '') :
                numberOfHeaderParamters = int(line[4 + NumberOfContextID])
            numberOfCells = 0   
            if ((5 + NumberOfContextID) < length) and (line[5 + NumberOfContextID] != '') :
                numberOfCells = int(line[5 + NumberOfContextID]) 
                
            previousCount = 0
            for cell in range (0, numberOfCells):
                numberOfParametersPerCell = 0
                if ((6 + NumberOfContextID + previousCount) < length) and (line[6 + NumberOfContextID + previousCount] != '') :
                    numberOfParametersPerCell = int(line[6 + NumberOfContextID + previousCount]) 
                previousCount += 1
                currentLog = LogDT()
                currentLog = copy.deepcopy(logObj)
                for parameter in range(0,numberOfParametersPerCell):
                    itemNumber = 7 + callContextIDCount + previousCount
                    previousCount += 1
                    
                    if parameter == 0:
                        if (itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.Band = parseCellMeasuresParseBand(line[itemNumber + parameter])
                    elif parameter == 1:
                        if (itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.ChannelNum = int(line[itemNumber + parameter])
                    elif parameter == 2:
                        if (itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.CellParameterID = int(line[itemNumber + parameter])
                    elif parameter == 4:
                        if (itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.URAID = int(line[itemNumber + parameter])
                listOfLogObj.append(currentLog)
        return 1
    else:
        dataOfCELLINFO = "No of context id not found"
        return 0


# In[ ]:




