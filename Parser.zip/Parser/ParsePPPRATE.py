#!/usr/bin/env python
# coding: utf-8

# In[2]:


from LogDTClass import LogDT


# In[26]:


def ParsePPPRATE (line, logObj):
    dataOfPPPRATE = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = int(line[2])
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.PPPThroughputUL = line[3+NumberOfContextID]
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            logObj.PPPThroughputDL = int(line[4+NumberOfContextID])
        return 1
    else:
        dataOfPPPRATE = "No of context id not found"
        return 0
#     except:
#         return 0

