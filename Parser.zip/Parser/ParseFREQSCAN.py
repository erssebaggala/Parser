#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
import copy
from MeasureSysConverter import MeasureSysConverter


# In[2]:


def ParseFREQSCAN (line, listOfLogObj, PREVIOUS_LAT,PREVIOUS_LONG,PREVIOUS_MCC,PREVIOUS_MNC):
    length = len(line)
    if 2 < length:
        dataOfFreqScan = ''
        callContextID = 0
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
            if NumberOfContextID != 0:
                if(3 < length) and (line[3] != '') :
                    callContextID = int(line[3])
                    dataOfFreqScan = "Call Context ID: " + callContextID
        logObj = LogDT()
        logObj.lat = PREVIOUS_LAT
        logObj.longg = PREVIOUS_LONG
        logObj.mcc = PREVIOUS_MCC
        logObj.mnc = PREVIOUS_MNC
        logObj.event = "Frequency scanning results"
        measureSystems=''
        numberOfHeaderParamters = 0
        numberOfChanels = 0
        numberOfParametersPerChannel = 0
        numberOfHARQProcesses = 0
        parametersPerHARQProcess = 0
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            measureSystems = int(line[3 + NumberOfContextID])
            logObj.modeSystem = MeasureSysConverter(measureSystems)
            
        if logObj.modeSystem == 'GSM':
            if ((4 + NumberOfContextID) < length) and (line[4 + NumberOfContextID] != '') :
                numberOfHeaderParamters = int(line[4 + NumberOfContextID])
            if ((5 + NumberOfContextID) < length) and (line[5 + NumberOfContextID] != '') :
                logObj.Band = int(line[5 + NumberOfContextID])
            if ((5 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[5 + NumberOfContextID + numberOfHeaderParamters] != '') :
                numberOfChanels = int(line[5 + NumberOfContextID + numberOfHeaderParamters])
            if ((6 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[6 + NumberOfContextID + numberOfHeaderParamters] != '') :
                numberOfParametersPerChannel = int(line[6 + NumberOfContextID + numberOfHeaderParamters])
            for channel in range (0, numberOfChanels):
                currentLog = LogDT()
                currentLog = copy.deepcopy(logDTObj)
                
                for parameter in range(1,numberOfParametersPerChannel):
                    itemNumber = 6 + NumberOfContextID + numberOfHeaderParamters + (channel * numberOfParametersPerChannel)
                    if parameter == 1:#ARFCN
                        if ((itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.ARFCNCurrent = int(line[itemNumber + parameter])
                    elif parameter == 2:#BSIC
                        if ((itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.BSIC = int(line[itemNumber + parameter])
                    elif parameter == 3:#RxLev Full
                        if ((itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.RxLevFull = float(line[itemNumber + parameter])
                    elif parameter == 4:#CI
                        if ((itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.CI = float(line[itemNumber + parameter])
                    elif parameter == 5:#SCH RX Level
                        if ((itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.SCHRxLev = float(line[itemNumber + parameter])
                        
                listOfLogObj.append(currentLog)
                            
        elif logObj.modeSystem == 'LTE FDD' or logObj.modeSystem == 'LTE TDD' or logObj.modeSystem == 'UMTS FDD':
            if ((4 + NumberOfContextID) < length) and (line[4 + NumberOfContextID] != '') :
                numberOfHeaderParamters = int(line[4 + NumberOfContextID])
            if ((5 + NumberOfContextID) < length) and (line[5 + NumberOfContextID] != '') :
                logObj.Band = int(line[5 + NumberOfContextID])
            if ((5 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[5 + NumberOfContextID + numberOfHeaderParamters] != '') :
                numberOfChanels = int(line[5 + NumberOfContextID + numberOfHeaderParamters])
            if ((6 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[6 + NumberOfContextID + numberOfHeaderParamters] != '') :
                numberOfParametersPerChannel = int(line[6 + NumberOfContextID + numberOfHeaderParamters])
            for channel in range (0, numberOfChanels):
                currentLog = LogDT()
                currentLog = copy.deepcopy(logDTObj)
                
                for parameter in range(1,numberOfParametersPerChannel):
                    itemNumber = 6 + NumberOfContextID + numberOfHeaderParamters + (channel * numberOfParametersPerChannel)
                    if parameter == 1:#Channel Num
                        if ((itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.ARFCNCurrent = int(line[itemNumber + parameter])
                    elif parameter == 2:#RSSI
                        if ((itemNumber + parameter) and (line[itemNumber + parameter] != '') :
                            currentLog.RSSI = float(line[itemNumber + parameter])
                        
                listOfLogObj.append(currentLog)
        return 1


# In[6]:


ParseCallType(50)


# In[ ]:




