#!/usr/bin/env python
# coding: utf-8

# In[15]:


def parseModulation(code,mode):
    if(mode == 'HSDPA'):
        switcher = { 
            1: "QPSK",
            2: "16QAM",
            3: "32QAM",
        } 
    elif(mode == 'HSUPA'):
        switcher = { 
            1: "QPSK",
            2: "16QAM",
        } 
    elif(mode == 'PDSCH'):
        switcher = { 
            1: "QPSK",
            2: "16QAM",
            3: "64QAM",
            4: "256QAM",
        }
    elif(mode == 'PUSCH'):
        switcher = { 
            1: "QPSK",
            2: "16QAM",
            3: "64QAM",
        }
    return switcher.get(code, "Unknown")

