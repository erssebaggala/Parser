#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def ParseApplicationProtocol(type):
    switcher = { 
        0: "Nemo protocol using modem connection",
        1: "Nemo protocol using TCP",
        2: "Nemo protocol using UDP",
        3: "FTP",
        4: "HTTP",
        5: "SMTP",
        6: "POP3",
        7: "MMS",
        8: "WAP 1.0",
        9: "Streaming",
        10: "WAP 2.0",
        11: "HTTP browsing",
        12: "ICMP ping",
        13: "IPerf over TCP",
        14: "IPerf over UDP",
        15: "Trace route",
        16: "SFTP",
        17: "IMAP",
        18: "Facebook",
        19: "Twitter",
        20: "Instagram",
        21: "LinkedIn",
        22: "PEVQ-S",
        23: "Dropbox",
    } 
    return switcher.get(type, "Unknown")

