#!/usr/bin/env python
# coding: utf-8

# In[1]:

from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
def ParseHOP (line, logObj):
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        codingType = 0
        logObj.event = "Frequency Hopping Status"
        logObj.msgType = ''
        logObj.time = line[1]  
        i = 0;           
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
        if logObj.modeSystem == 'GSM':
            if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                codingType = int(line[4+NumberOfContextID]) #add
                if codingType == 1:
                    logObj.HoppingStatus = 'ON' #add
                    if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
                        logObj.HSN = int(line[5+NumberOfContextID]) #add
                    if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                        logObj.MAIO = line[6+NumberOfContextID] #add  
                    if ((7 + NumberOfContextID) < length) and (line[7+NumberOfContextID] != '') :
                        hopingChannels = int(line[7+NumberOfContextID]) #add
                    for i in range(0,hopingChannels):
                        if i == 0:
                            logObj.HoppingChannels = line[8+NumberOfContextID]
                        else:
                            logObj.HoppingChannels = logObj.HoppingChannels + ',' +(line[8+NumberOfContextID])
                    
                elif codingType == 2:
                    logObj.HoppingStatus = 'OFF' #add
                    if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
                        logObj.HoppingChannels = line[5+NumberOfContextID] #add

        return 1
    
    else:
        return 0
#     except:
#         return 0


# In[ ]:




