#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def ParseStop (line):
    try:
        stopDate = ""
        time = line[1]
        date = line[-1]
        date = date[1:-1]
        stopDate = time + ' ' + date
        return stopDate
    except:
        return "Stop date not found"

