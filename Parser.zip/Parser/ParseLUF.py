#!/usr/bin/env python
# coding: utf-8

# In[3]:
from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from parseLUFmmCause import parseLUFmmCause
def ParseLUF (line, logObj):
    dataOfLUF = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        LUFContextID = 0
        LUFType = 0
        mmCause = 0
        logObj.event = "Location Area Update Failed"
        logObj.msgType = 'LUA Fail'
        logObj.time = line[1]  
        if (3 < length) and (line[3] != ''):
            LUFContextID = line[3]
        if int(LUFContextID) > 0:
            dataOfLUF = 'Location Update Context ID: ' + LUFContextID
                   
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            LUFType = int(line[4+NumberOfContextID]) #add
            if LUFType == 1:
                LUFType = 'Timeout'
            elif LUFType == 2:
                LUFType = 'Rejected by Network'
            elif LUFType == 3:
                LUFType = 'Rejected by network after combined location and routing area update (cause value is GMM cause)'
            else:
                LUFType = 'Unknown'
            
            dataOfLUF += (';Fail Cause: ' + LUFType) 
        if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
            logObj.OldLAC = int(line[5+NumberOfContextID]) #add
            dataOfLUF += (';Old LAC: ' + str(logObj.OldLAC)) 
        if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
            mmCause = line[6+NumberOfContextID]
            mmCause = parseLUFmmCause(mmCause)
            dataOfLUF += (';MM Cause: : ' + mmCause)    
       
        logObj.eventInfo = dataOfLUF 
        return 1
    
    else:
        dataOfLUF = "No of context id not found"
        return 0
#     except:
#         return 0


# In[ ]:




