#!/usr/bin/env python
# coding: utf-8

# In[ ]:

from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
def ParseCI (line, logObj):
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] !='':
            NumberOfContextID = int(line[2])
        logObj.event = "Carrier per longerface"
        logObj.msgType = ' '
        logObj.time = line[1]
        measureSystems=''
        numberOfHeaderParameters = 0
        cellTypes = 0
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            measureSystems = int(line[3 + NumberOfContextID])
            logObj.modeSystem = MeasureSysConverter(measureSystems)
            
        if logObj.modeSystem == 'GSM':
            if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                logObj.CI = float(line[4+NumberOfContextID]) #add
            if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                logObj.CIperTSL = float(line[6+NumberOfContextID]) #add
        elif logObj.modeSystem == 'LTE FDD' or logObj.modeSystem == 'LTE TDD':
            if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                numberOfHeaderParameters = int(line[4+NumberOfContextID]) #add
                if numberOfHeaderParameters > 0:
                    if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
                        logObj.SNR = float(line[5+NumberOfContextID]) #add
                    if numberOfHeaderParameters > 1:
                        if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                            cellTypes = int(line[6+NumberOfContextID])
                            #cellTypes = int(cellTypes)
                            if cellTypes == 0:
                                logObj.cellType = 'PCell'
                            elif cellTypes == 1:
                                logObj.cellType = 'SCell 0'
                            elif cellTypes == 2:
                                logObj.cellType = 'SCell 1'

        return 1
    else:
        return 0
#     except:
#         return 0

