#!/usr/bin/env python
# coding: utf-8

# In[2]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from ParseMimoMeasureMimoBand import parseMimoMeasureMimoBand
from ParseMimoMeasureMimoPort import parseMimoMeasureMimoPart


# In[26]:


def ParseMIMOMEAS (line, listOfLogObj):
    logDTObj = LogDT()
    dataOfMIMOMEAS = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = int(line[2])
        contextID = 'Unknown'
        numberOfHeaderParamters = 0
        numberOfMeasurements = 0
        numberOfParametersPerMeasurement = 0
        measureSystem = 'Unknown'
        if (3 < length) and (line[3] != ''):
            contextID = line[3]
            
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            measureSystem = line[3+NumberOfContextID]
            measureSystem = MeasureSysConverter(int(measureSystem))
            logDTObj.modeSystem = measureSystem
            
            if measureSystem == 'UMTS FDD':
                if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                    numberOfHeaderParamters = int(line[4+NumberOfContextID])
                    if numberOfHeaderParamters > 0:
                if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
                    numberOfMeasurements = int(line[5+NumberOfContextID])
                if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                    numberOfParametersPerMeasurement = int(line[6+NumberOfContextID])
                   
                for cell in range(0,numberOfMeasurements):
                    currentLog = LogDT()
                    for parameter in range(0,numberOfParametersPerMeasurement):
                        item = NumberOfContextID + 7 + (numberOfMeasurements * numberOfParametersPerMeasurement) + (cell * numberOfParametersPerMeasurement)
                        if parameter == 0:#Band
                            if ((item+1) < length) and (line[item+1] != '') :
                                cellType = int(line[item+1])
                                cellType = parseMimoMeasureMimoBand(cellType)
                                currentLog.MIMO_Band = cellType
                
                        elif parameter == 1:#Channel
                            if ((item+parameter) < length) and (line[item+parameter] != '') : 
                                currentLog.MIMO_Channel = parseMIMOMEASuresParseBand(int(line[item+parameter]))
                        elif parameter == 2:#Scrambling Code
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_ScramblingCode = int(line[item+parameter])
                        elif parameter == 3:#Antenna
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_AntennaPort = int(line[item+parameter])
                        elif parameter == 4:#Cell Type
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                cellTyp = int(line[item+parameter])
                                
                                if cellTyp == 0:
                                    currentLog.MIMO_CellType = 'Active'
                                elif cellTyp == 1:
                                    currentLog.MIMO_CellType = 'Monitored'
                                elif cellTyp == 2:
                                    currentLog.MIMO_CellType = 'Detected'
                                elif cellTyp == 3:
                                    currentLog.MIMO_CellType = 'Undetected'
                        elif parameter == 5:#RSSI
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_RSSI = line[item+parameter]
                        elif parameter == 6:#Ec/No
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_EcNo = line[item+parameter]
                        elif parameter == 7:#RSCP
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_RSCP = line[item+parameter]
                        
                
                    listOfLogObj.append(currentLog) 
                
                        
            elif measureSystem == "LTE FDD" or measureSystem == "LTE TDD":
                if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
                    numberOfHeaderParamters = int(line[4+NumberOfContextID])
                if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
                    numberOfCells = int(line[5+NumberOfContextID])
                if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
                    numberOfParametersPerCell = int(line[6+NumberOfContextID])
                                
                for cell in range(0,numberOfCells):
                    currentLog = LogDT()
                    for parameter in range(0,numberOfParametersPerCell):
                        item = NumberOfContextID + 7 +(cell*numberOfParametersPerCell)
                        if parameter == 0:#Band
                            if ((item+1) < length) and (line[item+1] != '') :
                                cellType = int(line[item+1])
                                currentLog.MIMO_Band = parseMIMOMEASuresParseBand(cellType)
                                
                        elif parameter == 0:#Band
                            if ((item+parameter) < length) and (line[item+parameter] != '') : 
                                currentLog.Band = parseMIMOMEASuresParseBand(int(line[item+parameter]))
                        elif parameter == 1:#ChannelNum
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_Channel = int(line[item+parameter])
                        elif parameter == 2:#PCI
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_PCI = int(line[item+parameter])
                        elif parameter == 3:#Port
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_Port = parseMimoMeasureMimoPart(int(line[item+parameter]))
                        elif parameter == 4:#Cell Type
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                celltype = int(line[item+parameter])
                                if celltype == 0:
                                    currentLog.MIMO_CellType = 'Serving'
                                if celltype == 10:
                                    currentLog.MIMO_CellType = 'SCell 0'
                                if celltype == 11:
                                    currentLog.MIMO_CellType = 'SCell 1'
                        elif parameter == 5:#RSSI
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_RSSI = float(line[item+parameter])
                        elif parameter == 6:#RSRQ
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_RSRQ = float(line[item+parameter])
                        elif parameter == 7:#RSRP
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_RSRP = float(line[item+parameter])
                        elif parameter == 8:#Timing
                            if ((item+parameter) < length) and (line[item+parameter] != '') :
                                currentLog.MIMO_Timing = float(line[item+parameter])
                        
                    listOfLogObj.append(currentLog) 
                
                
        dataOfMIMOMEAS = "Context ID:"+contextID
        logObj.eventInfo = dataOfMIMOMEAS
        return 1, listOfLogObj
    else:
        dataOfMIMOMEAS = "No of context id not found"
        return 0
#     except:
#         return 0

