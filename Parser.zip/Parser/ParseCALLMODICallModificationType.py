#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseCALLMODICallModificationType(type):
    switcher = { 
        101: "LTE IMS voice -> GSM voice",
        102: "LTE IMS voice -> UMTS voice",
        103: "LTE IMS voice -> CDMA voice",
        110: "LTE IMS voice -> LTE IMS video",
        130: "LTE IMS voice -> WLAN IMS voice",
        140: "LTE IMS voice -> WLAN IMS video",
        201: "LTE IMS video -> GSM voice",
        202: "LTE IMS video -> UMTS voice",
        203: "LTE IMS video -> CDMA voice",
        210: "LTE IMS video -> LTE IMS voice",
        230: "LTE IMS video -> WLAN IMS voice",
        240: "LTE IMS video -> WLAN IMS video",
        310: "WLAN IMS voice -> LTE IMS voice",
        320: "WLAN IMS voice -> LTE IMS video",
        340: "WLAN IMS voice -> WLAN IMS video",
        410: "WLAN IMS video -> LTE IMS voice",
        420: "WLAN IMS video -> LTE IMS video",
        430: "WLAN IMS video -> WLAN IMS voice",
    } 
    return switcher.get(type, "Unknown")

