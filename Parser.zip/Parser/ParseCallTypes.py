#!/usr/bin/env python
# coding: utf-8

# In[3]:


def ParseCallType(type):
    switcher = { 
        1: "Voice call", 
        2: "Markov call", 
        3: "Data call",
        4: "Fax call", 
        5: "Dial-up based data call", 
        6: "Loopback call (CDMA)",  
        7: "Video call", 
        8: "Push-to-talk",
        9: "Push-to-talk between mobiles (TETRA)", 
        10: "VoIP", 
        11: "Skype",
        12: "QChat", 
        13: "Kodiak",
        14: "VoLTE", 
        15: "iDEN push-to-talk",
        16: "LTE IMS video", 
        17: "WLAN IMS voice",
        18: "WLAN IMS video",
    } 
    return switcher.get(type, "Unknown")


# In[6]:


ParseCallType(50)


# In[ ]:




