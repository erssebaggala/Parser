#!/usr/bin/env python
# coding: utf-8

# In[ ]:

from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
def ParseRUS (line, logObj):
    dataOfRUS = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        RUSContextID = 0
        RUSType = 0
        logObj.event = "Routing Area Update Attempt"
        logObj.msgType = 'Setup'
        logObj.time = line[1]  
        if (3  < length) and (line[3] != '') :
            RUSContextID = line[3]
            dataOfRUS = "RUS Context ID: " + RUSContextID + ';'
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
            dataOfRUS += ('Measure System: ' + logObj.modeSystem) + ';'
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            logObj.OldRAC = (line[4 + NumberOfContextID])
            dataOfRUS += ('Old RAC: ' + logObj.OldRAC) + ';'
        if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
            logObj.OldLAC = (line[5+NumberOfContextID]) #add
            dataOfRUS += ('Old LAC: ' + logObj.OldLAC) + ';'
        if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
            logObj.RAC = (line[6 + NumberOfContextID])
            dataOfRUS += ('RAC: ' + logObj.RAC) + ';'
        if ((7 + NumberOfContextID) < length) and (line[7+NumberOfContextID] != '') :
            logObj.LAC = (line[7+NumberOfContextID]) #add
            dataOfRUS += ('LAC: ' + logObj.LAC) + ';'
        
        logObj.eventInfo = dataOfRUS 
        return 1
    
    else:
        dataOfRUS = "No of context id not found"
        return 0
#     except:
#         return 0

