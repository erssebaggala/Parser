#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class DataConnectionEventInfo:
    def __init__(self,DataConnectionContextID ='',PacketSessionContextID ='',CallContextID ='',DataTransferContextID ='',AttemptTime ='',SuccessTime ='',FailureTime='',DisconnectTime='',DataTransferRequestTime='',DataTransferCompleteTime='',ApplicationProtocol=''):
        self.DataConnectionContextID = DataConnectionContextID
        self.PacketSessionContextID = PacketSessionContextID
        self.CallContextID  = CallContextID
        self.DataTransferContextID = DataTransferContextID
        self.AttemptTime = AttemptTime
        self.SuccessTime = SuccessTime
        self.FailureTime = FailureTime
        self.DisconnectTime = DisconnectTime
        self.DataTransferRequestTime = DataTransferRequestTime
        self.DataTransferCompleteTime = DataTransferCompleteTime
        self.ApplicationProtocol = ApplicationProtocol

