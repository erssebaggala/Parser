#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseHOFStringType(type):
    switcher = { 
        "0": "RR Cause: Normal event; ",
        "1": "RR Cause: Abnormal release, unspecified; ",
        "2": "RR Cause: Abnormal release, channel unacceptable; ",
        "3": "RR Cause: Abnormal release, timer expired; ",
        "4": "RR Cause: Abnormal release, no activity on the radio path; ",
        "5": "RR Cause: Pre-emtive release; ",
        "6": "RR Cause: UTRAN configuration unknown; ",
        "8": "RR Cause: Handover impossible, timing advance out of range; ",
        "9": "RR Cause: Channel mode unacceptable; ",
        "10": "RR Cause: Frequency not implemented; ",
        "11": "RR Cause: Originator or talker leaving group call area; ",
        "12": "RR Cause: Lower layer failure; ",
        "65": "RR Cause: Call already cleared; ",
        "95": "RR Cause: Semantically incorrect message; ",
        "96": "RR Cause: Invalid mandatory information; ",
        "97": "RR Cause: Message type non-existent or not implemented; ",
        "98": "RR Cause: Message type not compatible with protocol state; ",
        "100": "RR Cause: Conditional IE error; ",
        "101": "RR Cause: No cell allocation available; ",
        "111": "RR Cause: Protocol error unspecified; ",
    } 
    return switcher.get(type, "Unknown")

