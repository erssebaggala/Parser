#!/usr/bin/env python
# coding: utf-8

# In[2]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter


# In[26]:


def ParseHSSCCHI (line, listOfLogObj, PREVIOUS_LAT,PREVIOUS_LONG,PREVIOUS_MCC,PREVIOUS_MNC):
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        logObj = LogDT()
        logObj.lat = PREVIOUS_LAT
        logObj.longg = PREVIOUS_LONG
        logObj.mcc = PREVIOUS_MCC
        logObj.mnc = PREVIOUS_MNC
        logObj.event = " HS-SCCH channel information"
        measureSystems=''
        numberOfHeaderParamters = 0
        numberOfChannels = 0
        parametersPerChannel = 0
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            measureSystems = int(line[3 + NumberOfContextID])
            logObj.modeSystem = MeasureSysConverter(measureSystems)
            
        if logObj.modeSystem == 'UMTS FDD':
            if ((4 + NumberOfContextID) < length) and (line[4 + NumberOfContextID] != '') :
                numberOfHeaderParamters = int(line[4 + NumberOfContextID])
            if ((5 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[5 + NumberOfContextID + numberOfHeaderParamters] != '') :
                numberOfChannels = int(line[5 + NumberOfContextID + numberOfHeaderParamters])
            if ((6 + NumberOfContextID + numberOfHeaderParamters) < length) and (line[6 + NumberOfContextID + numberOfHeaderParamters] != '') :
                parametersPerChannel = int(line[6 + NumberOfContextID + numberOfHeaderParamters])
            
            for channel in range (0, numberOfChannels):
                for param in range(0, parametersPerChannel):
                    if ((7 + NumberOfContextID + numberOfHeaderParamters + param) < length) and (line[7 + NumberOfContextID + numberOfHeaderParamters + param] != '') :
                        value = line[7 + NumberOfContextID + numberOfHeaderParamters + param]
                    
                    if param == 0:#HS-SCCH Code
                        logObj.HSSCCHCode = int(value)
                    elif param == 1:#HS-SCCH Usage
                        logObj.HSSCCHUsage = float(value)
                    elif param == 2:#Cell Type
                        if value == '1':
                            logObj.cellType = 'Primary'
                        else:
                            logObj.cellType = 'Secondary'
                        
                listOfLogObj.append(logObj)

        return 1
    else:
        return 0
#     except:
#         return 0

