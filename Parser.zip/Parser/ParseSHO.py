#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from HOEventInfo import HOEventInfo
from ParseCellMeasuresParseBand import parseCellMeasuresParseBand
from ParseHOAHandoverType import parseHOAHandoverType


# In[2]:


def ParseSHO (line, logObj):
    length = len(line)
    if 2 < length:
        dataOfSHO = ''
        mainHeaderCount = 0
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
            if NumberOfContextID != 0:
                if((3+NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
                    mainHeaderCount = int(line[3+NumberOfContextID])

        logObj.event = "Soft Handover"
        logObj.msgType = 'Soft Handover'
        modeSystem = "Unknown"
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
        if modeSystem == 'UMTS FDD':
            if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != ''):
                event = line[4+NumberOfContextID]  
                
                if event == '1':
                    logObj.event = 'Successful Soft Handover'
                elif event == '2':
                    logObj.event = 'Failed Soft Handover'
            if ((5 + NumberOfContextID) < length) and (line[5 + NumberOfContextID] != ''):
                param = line[5 + NumberOfContextID]
                if param == '0':
                    dataOfSHO += 'RRC Cause: Configuration unsupported; '
                elif param == '1':
                    dataOfSHO += 'RRC Cause: Physical channel failure; '
                elif param == '2':
                    dataOfSHO += 'RRC Cause: Incompatible simultaneous reconfiguration; '
                elif param == '3':
                    dataOfSHO += 'RRC Cause: Protocol error; '
                elif param == '4':
                    dataOfSHO += 'RRC Cause: Compressed mode runtime error; '
                elif param == '5':
                    dataOfSHO += 'RRC Cause: Cell update occurred; '
                elif param == '6':
                    dataOfSHO += 'RRC Cause: Invalid configuration; '
                elif param == '7':
                    dataOfSHO += 'RRC Cause: Configuration incomplete; '
                elif param == '8':
                    dataOfSHO += 'RRC Cause: Unsupported measurement; '
                elif param == '9':
                    dataOfSHO += 'RRC Cause: MBMS session already received correctly; '
                elif param == '10':
                    dataOfSHO += 'RRC Cause: Lower priority MBMS service; '
            if ((6 + NumberOfContextID) < length) and (line[6 + NumberOfContextID] != ''):
                dataOfSHO += "# of SCs Added: "+line[6 + NumberOfContextID]+';'
            if len(line) > 8 and ((8 + NumberOfContextID) < length) and (line[8 + NumberOfContextID] != ''):
                dataOfSHO += 'Added SC: ' + line[8 + NumberOfContextID]
            if ((7 + NumberOfContextID) < length) and (line[7 + NumberOfContextID] != ''):
                dataOfSHO += "# of SCs Removed: "+line[7 + NumberOfContextID]+';'
            if len(line) > 9 and ((9 + NumberOfContextID) < length) and (line[9 + NumberOfContextID] != ''):
                dataOfSHO += 'Removed SC: ' + line[9 + NumberOfContextID]
                
        logObj.eventInfo = dataOfSHO
                                                 
        return 1


# In[ ]:




