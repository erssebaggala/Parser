#!/usr/bin/env python
# coding: utf-8

# In[1]:


def parseGpsQuality(type):
    switcher = { 
        "-1": "Simulated GPS fix",
        "0": "No fix",
        "1": "GPS fix",
        "2": "DGPS fix",
        "3": "DR in use",
        "4": "GPS estimation",
        "5": "GPS fix with DR",
        "6": "DGPS fix with DR",
        "11": "Glonass fix",
        "21": "GPS + Glonass fix",
    } 
    return switcher.get(type, "Unknown")

