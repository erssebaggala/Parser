#!/usr/bin/env python
# coding: utf-8

# In[1]:


from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from HOEventInfo import HOEventInfo
from ParseCellMeasuresParseBand import parseCellMeasuresParseBand
from ParseHOAHandoverType import parseHOAHandoverType

# In[2]:


def ParseHOA (line, logObj,dictionary):
    length = len(line)
    if 2 < length:
        dataOfHOA = ''
        handoverContextID = 0
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
            if NumberOfContextID != 0:
                if(3 < length) and (line[3] != '') :
                    handoverContextID = int(line[3])

        logObj.event = "Handover Attempt"
        logObj.msgType = 'Handover Command'
        dataOfHOA = "Handover Context ID: " + str(handoverContextID)
        measureSystems=''
        mainHeaderCount = 0
        handoverType = "Unknown"
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            mainHeaderCount = int(line[3 + NumberOfContextID])
            if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') and mainHeaderCount > 0:
                handoverType = line[4+NumberOfContextID]
                handoverType = parseHOAHandoverType(handoverType)
                logObj.HandoverType = handoverType
                dataOfHOA += (";Handover Type: " + handoverType) 
            
        if ((4 + NumberOfContextID + mainHeaderCount) < length) and (line[4 + NumberOfContextID + mainHeaderCount] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[4 + NumberOfContextID + mainHeaderCount]))
            
        if handoverContextID in dictionary:
            HOAInfo = dictionary[handoverContextID]
        else:
            HOAInfo = HOEventInfo()
            dictionary[handoverContextID] = HOAInfo
            HOAInfo = dictionary[handoverContextID]
         
        HOAInfo.HOAttempt = line[1]
        HOAInfo.ModeSystem = logObj.modeSystem
        HOAInfo.HOType = handoverType
         
        dictionary[handoverContextID] =  HOAInfo 
        currentSystemParameterCount = 0
        if ((5 + NumberOfContextID + mainHeaderCount) < length) and (line[5 + NumberOfContextID + mainHeaderCount] != '') :
            currentSystemParameterCount = (int(line[5 + NumberOfContextID + mainHeaderCount]))
            
        if logObj.modeSystem == 'GSM' or logObj.modeSystem == 'UMTS FDD':
            for parameter in range(1,currentSystemParameterCount):
                itemNumber = 6 + NumberOfContextID + mainHeaderCount
                if parameter == 1:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.ChannelNum = int(line[itemNumber + parameter])
                elif parameter == 2:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.TSL = int(line[itemNumber + parameter])
                elif parameter == 3:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.Band = parseCellMeasuresParseBand(int(line[itemNumber + parameter]))
                        
        elif logObj.modeSystem == 'LTE FDD' or logObj.modeSystem == 'LTE TDD':
            for parameter in range(1,currentSystemParameterCount):
                itemNumber = 6 + NumberOfContextID + mainHeaderCount
                if parameter == 1:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.ChannelNum = int(line[itemNumber + parameter])
                elif parameter == 2:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.PCI = int(line[itemNumber + parameter])
                elif parameter == 3:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.Band = parseCellMeasuresParseBand(int(line[itemNumber + parameter]))
                        
                        
        if ((4 + NumberOfContextID + mainHeaderCount) < length) and (line[4 + NumberOfContextID + mainHeaderCount] != '') : 
            attemptedSystem = MeasureSysConverter(line[4 + NumberOfContextID + mainHeaderCount])
            logObj.AttemptedSystem = attemptedSystem
                                                 
        attemptedSystemParameterCount = 0
        if ((5 + NumberOfContextID + mainHeaderCount) < length) and (line[5 + NumberOfContextID + mainHeaderCount] != '') :
            attemptedSystemParameterCount = (int(line[5 + NumberOfContextID + mainHeaderCount]))
            
        if attemptedSystem == 'GSM':
            for parameter in range(1,attemptedSystemParameterCount):
                itemNumber = 6 + NumberOfContextID + mainHeaderCount
                if parameter == 1:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedChannel = int(line[itemNumber + parameter])
                elif parameter == 2:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedTSL = int(line[itemNumber + parameter])
                elif parameter == 3:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedBand = parseCellMeasuresParseBand(int(line[itemNumber + parameter]))
                        
        elif attemptedSystem == 'UMTS FDD':
            for parameter in range(1,attemptedSystemParameterCount):
                itemNumber = 6 + NumberOfContextID + mainHeaderCount
                if parameter == 1:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedChannel = int(line[itemNumber + parameter])
                elif parameter == 2:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedSC = int(line[itemNumber + parameter])
                elif parameter == 3:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedBand = parseCellMeasuresParseBand(int(line[itemNumber + parameter]))
          
        elif attemptedSystem == "LTE FDD" or attemptedSystem == "LTE TDD":
            for parameter in range(1,attemptedSystemParameterCount):
                itemNumber = 6 + NumberOfContextID + mainHeaderCount
                if parameter == 1:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedChannel = int(line[itemNumber + parameter])
                elif parameter == 2:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedPCI = int(line[itemNumber + parameter])
                elif parameter == 3:
                    if ((itemNumber + parameter) < length) and (line[itemNumber + parameter] != '') :
                        logObj.AttemptedBand = parseCellMeasuresParseBand(int(line[itemNumber + parameter]))
                                                 
        logObj.eventInfo = dataOfHOA
                                                 
        return 1



