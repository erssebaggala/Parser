#!/usr/bin/env python
# coding: utf-8

# In[2]:


def parseDAFFtpSftpFailStatus(type):
    switcher = { 
        1: "Timeout",
        2: "Invalid remote address",
        3: "Invalid username/password",
        4: "Invalid remote file",
        5: "Invalid local file",
        104: "Already connected",
        116: "Remote port cannot be zero",
        118: "Firewall error",
        120: "Service ready in nnn minutes",
        135: "Operation would block",
        141: "Unspecified FTP protocol error",
        202: "Command not implemented superfluous at this site",
        211: "Action impossible in control's present state",
        212: "Action impossible while connected",
        213: "Action impossible while listening",
        421: "Service not available closing control connection",
        425: "Cannot open data connection",
        426: "Connection closed transfer aborted",
        434: "Requested host unavailable",
        450: "Requested file action not taken. File unavailable (e.g. file busy)",
        451: "Requested action aborted local error in processing",
        452: "Requested action not taken. Insufficient storage space in system",
        500: "Syntax error command unrecognized. This may include errors such as command line too long",
        501: "Syntax error in parameters or arguments",
        502: "Command not implemented",
        503: "Bad sequence of commands",
        504: "Command not implemented for that parameter",
        530: "User not logged in",
        532: "Need account for storing files",
        550: "Requested action not taken file unavailable (e.g. file not found no access)",
        552: "Requested file action aborted storage allocation exceeded",
        553: "Requested action not taken illegal file name",
        1032: "Password authentication failed SFTP only.",
        1102: "Unrecognized remote SSH version string format SFTP only.",
        1103: "SFTP command failed SFTP only.",
        1105: "Already connecting close the current connection first SFTP only.",
        1120: "Connection dropped by remote host SFTP only.",
    } 
    return switcher.get(type, "Unknown")


# In[ ]:




