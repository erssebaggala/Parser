#!/usr/bin/env python
# coding: utf-8

# In[17]:


def ParseFF (line):
    try:
        version = ""
        version = (line[-1])
        version = version[1:-1]
        return version
    except:
        return "Version not found"

