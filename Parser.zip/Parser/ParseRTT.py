#!/usr/bin/env python
# coding: utf-8

# In[ ]:
from LogDTClass import LogDT
from ParseApplicationProtocol import ParseApplicationProtocol

def ParseRTT (line, logObj):
    dataOfRTT = ""
    length = len(line)
    if 2 < length:
        applicationProtocol = "Unknown"
        NumberOfContextID = int(line[2])

        logObj.event = "Round Trip Time"
        logObj.msgType = ' '
        logObj.time = line[1]
        if (3 < length) and (line[3] != ''):
            dataTranferContextID = line[3]

        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.applicationProtocol = line[3 + NumberOfContextID]
            applicationProtocol = ParseApplicationProtocol(int(logObj.applicationProtocol))
            
         #add in logObj   
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            logObj.PingSize = line[4+NumberOfContextID] #add
        if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
            logObj.PingRTT = line[5+NumberOfContextID] #add
        
        dataOfRTT = "Data Transfer Context ID: "+dataTranferContextID+";Application Protocol: "+applicationProtocol

        logObj.eventInfo = dataOfRTT
        return 1
    else:
        dataOfRTT = "No of context id not found"
        return 0
#     except:
#         return 0

