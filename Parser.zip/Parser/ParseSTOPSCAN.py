#!/usr/bin/env python
# coding: utf-8

# In[ ]:
from LogDTClass import LogDT
from ScanEventInfo import ScanEventInfo
from datetime import datetime

def ParseSTOPSCAN (line, logObj,dictionary):
    length = len(line)
    if 2 < length:
        dataOfStopScan = ''
        scanContextID = 0
        NumberOfContextID = int(line[2])
        logObj.event = "Scanning Stop"
        logObj.msgType = 'Release'
        logObj.time = line[1]
        dataOfStopScan += 'Scanning Stop'
        if (NumberOfContextID > 0) and (((3) < length) and (line[3] != '')):
            scanContextID = int(line[3])
        if scanContextID > 0:
            if scanContextID in dictionary:
                scanInfo = dictionary[scanContextID]
            else:
                scanInfo = ScanEventInfo()
                dictionary[scanContextID] = scanInfo
                scanInfo = dictionary[scanContextID]
                
            scanInfo.EndTime = logObj.time
            
            delta = datetime.strptime(scanInfo.EndTime.split('.', 1)[0], '%H:%M:%S') - datetime.strptime(scanInfo.StartTime.split('.', 1)[0], '%H:%M:%S')        
            totalScanTime = float(delta.seconds)*1000 #MilliSeconds 
        
            dataOfStopScan += (';Scanning Context ID:' + str(scanContextID) +";Total scan Time: " + str(totalScanTime)) #find this time in msecs
        logObj.eventInfo = dataOfStopScan
        return 1
    else:
        return 0
#     except:
#         return 0

