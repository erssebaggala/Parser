#!/usr/bin/env python
# coding: utf-8

# In[ ]:
from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter

def ParseROAM (line, logObj):
    dataOfROAM = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        roamingStatus = 0
        logObj.event = "Roaming information"
        logObj.msgType = ''
        logObj.time = line[1]  
                   
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            roamingStatus = int(line[4+NumberOfContextID])
            if SEIType == 1:
                dataOfROAM = 'Roaming Status: Roaming'
            elif roamingStatus == 2:
                dataOfROAM = 'Roaming Status: Not Roaming'
        logObj.eventInfo = dataOfROAM 
        return 1
    
    else:
        dataOfROAM = "No of context id not found"
        return 0
#     except:
#         return 0

