#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def parseDADDataDisconnectStatus(type):
    switcher = { 
        1: "Normal data disconnect", 
        2: "Socket error", 
        3: "Protocol error or timeout",
        4: "Test system failure",
    } 
    return switcher.get(type, "Unknown")

