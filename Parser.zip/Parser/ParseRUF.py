#!/usr/bin/env python
# coding: utf-8

# In[ ]:

from LogDTClass import LogDT
from MeasureSysConverter import MeasureSysConverter
from ParseRUFGsmCause import parseRUFGsmCause
def ParseRUF (line, logObj):
    dataOfRUF = ""
    length = len(line)
    if 2 < length:
        NumberOfContextID = 0
        if line[2] != '':
            NumberOfContextID = int(line[2])
        RUFContextID = 0
        attemptedRAC = 0
        attemptedLAC = 0
        gsmCause = 'Unknown'
        logObj.event = "Routing Area Update Failed"
        logObj.msgType = 'Failure'
        logObj.time = line[1]  
        if (3  < length) and (line[3] != '') :
            RUFContextID = line[3]
            dataOfRUF = "RUF Context ID: " + RUFContextID + ';'
        if ((3 + NumberOfContextID) < length) and (line[3+NumberOfContextID] != '') :
            logObj.modeSystem = MeasureSysConverter(int(line[3 + NumberOfContextID]))
            dataOfRUF += ('Measure System: ' + logObj.modeSystem) + ';'
        if ((4 + NumberOfContextID) < length) and (line[4+NumberOfContextID] != '') :
            attemptedRAC = int(line[4 + NumberOfContextID])
            dataOfRUF += ('Attempted RAC:  ' + str(attemptedRAC)) + ';'
        if ((5 + NumberOfContextID) < length) and (line[5+NumberOfContextID] != '') :
            attemptedLAC = int(line[5+NumberOfContextID]) #add
            dataOfRUF += ('Attempted LAC: ' + str(attemptedLAC)) + ';'
        if ((6 + NumberOfContextID) < length) and (line[6+NumberOfContextID] != '') :
            gsmCause = parseRUFGsmCause(int(line[6 + NumberOfContextID]))
            dataOfRUF += ('GMM Cause: ' + str(gsmCause)) + ';'
        
        logObj.eventInfo = dataOfRUF 
        return 1
    
    else:
        dataOfRUF = "No of context id not found"
        return 0
#     except:
#         return 0

